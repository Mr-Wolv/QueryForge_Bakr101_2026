/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.dev/license
 */
// THIS CODE IS GENERATED - DO NOT MODIFY.
const u = undefined;
function plural(val) {
    const n = val;
    return 5;
}
export default ["bgn-IR", [["AM", "PM"]], u, [["S", "M", "T", "W", "T", "F", "S"], ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]], u, [["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"], ["M01", "M02", "M03", "M04", "M05", "M06", "M07", "M08", "M09", "M10", "M11", "M12"]], u, [["BCE", "CE"]], 6, [5, 5], ["y-MM-dd", "y MMM d", "y MMMM d", "y MMMM d, EEEE"], ["HH:mm", "HH:mm:ss", "HH:mm:ss z", "HH:mm:ss zzzz"], ["{1} {0}", u, u, u], ["٫", "،", ";", "٪", "+", "-", "E", "×", "‰", "∞", "ناعدد", ":"], ["#,##0.###", "#,##0%", "¤ #,##0.00", "#E0"], "IRR", "ریال", "ایرانئ ریال", { "AFN": ["؋"], "IRR": ["ریال"], "JPY": ["JP¥", "¥"], "USD": ["US$", "$"] }, "rtl", plural];
//# sourceMappingURL=bgn-IR.js.map